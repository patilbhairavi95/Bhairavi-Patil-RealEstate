import { Component } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminservicesService } from '../../showServices/adminservices.service';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SidebarComponent } from "../../sidebar/sidebar/sidebar.component";
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule, SidebarComponent],
  templateUrl: './add.component.html',
  styleUrl: './add.component.css'
})
export class AddComponent {
  reactiveForm:FormGroup=new FormGroup({serviceName:new FormControl(""),
    serviceType:new FormControl(""),
    serviceCategory:new FormControl(""),
    servicePrice:new FormControl(""),
    serviceAddress:new FormControl(""),
    serviceMeasure:new FormControl(""),
    serviceDesc:new FormControl(""),
    img1:new FormControl(""),
    img2:new FormControl(""),
    img3:new FormControl(""),
    img4:new FormControl("")
  })
  constructor(private AServices:AdminservicesService,private route:Router){
  
  }
  
  addService(){
    console.log(this.reactiveForm.value);
    
    this.AServices.addServices(this.reactiveForm.value).subscribe((data:any)=>{
      console.log(data);
      alert("product added succefully");
      this.route.navigate(['/showservice']);
    
      },
    //   (error )=> {
    //     console.error('Error Adding product:', error);
    //     alert('Error Adding product.');
    // })
    )
    
  }

}
