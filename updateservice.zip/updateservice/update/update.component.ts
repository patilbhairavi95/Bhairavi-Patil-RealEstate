import { Component } from '@angular/core';
import { serviceinfo } from '../../showServices/showservice/showservice';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { AdminservicesService } from '../../showServices/adminservices.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SidebarComponent } from "../../sidebar/sidebar/sidebar.component";

@Component({
  selector: 'app-update',
  imports: [CommonModule, FormsModule, RouterModule, ReactiveFormsModule, SidebarComponent],
  templateUrl: './update.component.html',
  styleUrl: './update.component.css'
})
export class UpdateComponent {
//   updateSer:serviceinfo={
//     serviceId:0,
//     serviceName:'',
//     serviceType:0,
//     serviceCategory:'',
//     servicePrice:0,
//     serviceAddress:'',
//     serviceMeasure:0,
//     serviceDesc:'',
//     img1:'',
//     img2:'',
//     img3:'',
//     img4:'',
//   };
//   id:number=0;
//   constructor(private _route:ActivatedRoute ,private Aservices:AdminservicesService,private route:Router){
//   this._route.queryParams.subscribe(params=>{
//     if(params['services']){
//       this.updateSer=JSON.parse(params['services']);
//       console.log(this.updateSer);
//     }
//   })
// this._route.params.subscribe(params => {
//   this.id = params['id'] || 0; 
// });
//   }

// updateService() {
//   this.updateSer.
//   serviceId=this.id;
//   console.log('updating product', this.updateService);
//   this.Aservices.editServices(this.updateSer).subscribe((data)=>
//   {
//     console.log('Product updated successfully', data);
//         alert('Product updated successfully!');
       
//         this.route.navigate(['/showservice'])
//       },
//       (error )=> {
//         console.error('Error updating product:', error);
//         alert('Error updating product.');
//   })
  
  
// }
// }
updateSer: serviceinfo = {
  serviceId: 0,
  serviceName: '',
  serviceType: 0,
  serviceCategory: '',
  servicePrice: 0,
  serviceAddress: '',
  serviceMeasure: 0,
  serviceDesc: '',
  img1: '',
  img2: '',
  img3: '',
  img4: '',
};
id: number = 0;

constructor(
  private _route: ActivatedRoute,
  private Aservices: AdminservicesService,
  private route: Router
) {
  this._route.queryParams.subscribe((params) => {
    if (params['services']) {
      this.updateSer = JSON.parse(params['services']);
      console.log(this.updateSer);
    }
  });

 /*  this._route.params.subscribe((params) => {
    this.id = params['id'] || 0;
  }); */
}

updateService() {
 // this.updateSer.serviceId = this.id;
  this.Aservices.editServices(this.updateSer).subscribe(
    (data) => {
      console.log('Product updated successfully', data);
      alert('Product updated successfully!');
      this.route.navigate(['/showservice']);
    },
    (error) => {
      console.error('Error updating product:', error);
      alert('Error updating product.');
    }
  );
}
}
  



