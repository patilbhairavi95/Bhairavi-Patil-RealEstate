import { Component } from '@angular/core';
import { AppComponent } from "../../app.component";
import { SidebarComponent } from "../../sidebar/sidebar/sidebar.component";
import { CommonModule } from '@angular/common';
import { serviceinfo } from './showservice';
import { AdminservicesService } from '../adminservices.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-showservice',
  imports: [AppComponent, SidebarComponent,CommonModule],
  templateUrl: './showservice.component.html',
  styleUrl: './showservice.component.css'
})
export class ShowserviceComponent {
  servicesList:serviceinfo[]=[]
  id:number=0;
 
   constructor(private Aservices:AdminservicesService,private route:Router,private http:HttpClient){
    console.log("constructor...");
    
   }

  ngOnInit(): void {
   console.log("oninit..");
   this.Aservices.getServices().subscribe((data:any)=>
  {
    console.log(data);
    this.servicesList=data;
    console.log(this.servicesList);
  })
  }
  editService(Service:any){
    console.log(Service);
        const servicedata=JSON.stringify(Service);
    this.route.navigate(['/update'],{queryParams:{services:servicedata}});
    console.log(servicedata);

  }
  
  loadServices() {
   
    this.Aservices.getServices().subscribe(
      (data: any) => {
        this.Aservices = data; 
      },
      (error) => {
        console.error('Error loading services:', error);
      }
    );
  }
  deleteService(serviceId: number) {
    // Call the service to delete the service by ID
    this.Aservices.deleteServices(serviceId).subscribe(
      () => {
        // On success, alert the user and reload the services list
        alert("Service deleted successfully");
        this.loadServices(); // Reload the services list after deletion
      },
      (error) => {
        console.error('Error deleting service:', error);
        alert('Failed to delete the service');
      }
    );
  }
  
  


}
