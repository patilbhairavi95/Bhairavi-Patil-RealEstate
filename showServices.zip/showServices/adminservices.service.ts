import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AdminservicesService {

  baseUrl="http://localhost:8081"
  constructor(private _http:HttpClient) { } 
  getServices(){
    return this._http.get(`${this.baseUrl}/Service`)
  }
  
  deleteServices(id:number){
    return this._http.delete(`${this.baseUrl}/Service/${id}`);
  }
  addServices(service:any){
   console.log(service);
   return this._http.post(`${this.baseUrl}/Service`,service)
  }
  editServices(service:any){
    const servicedata=JSON.stringify(service);
    return this._http.put(`${this.baseUrl}/Service`,service);
    
    
  }
}
